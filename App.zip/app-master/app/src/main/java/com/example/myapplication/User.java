package com.example.myapplication;

public class User {
    public String fullName, email, address, phone;

    public User(){

    }

    public User(String fullName, String email, String address, String phoneNo) {
        this.fullName = fullName;
        this.email = email;
        this.address = address;
        this.phone = phoneNo;
    }

}

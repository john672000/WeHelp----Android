# Waste-Management-App
An android app to donate food, books and clothes to orphanage / old age homes.
